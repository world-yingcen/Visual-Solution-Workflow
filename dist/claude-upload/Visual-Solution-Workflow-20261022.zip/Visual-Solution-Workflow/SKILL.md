---
name: Visual-Solution-Workflow
description: 在 Claude 網頁／App 依品牌資料規劃與製作整體視覺網站，專注品牌、視覺、動態提案與確認流程，切版與動畫技術使用另外啟用的 Lin-EVO／GSAP Skills；適用提案、製作及續作。
---

# Visual-Solution-Workflow

整體視覺網站流程｜Claude 網頁／App 上傳版

以繁體中文與台灣用語協作。先讀 [整體視覺主流程](resources/workflow/GUIDE.md)，
切版／修改／校稿依使用者另外啟用的 Lin-EVO；動畫技術按需使用獨立 GSAP Skills。
resources 內的 GUIDE.md 都是本包參考，不是需要另外安裝的 Skill。

## 此上傳環境的優先規則

本節優先於參考中僅適用本機的安裝、更新、工具或派工指令；
品牌、設計、工程與使用者已確認規格仍保留，不擅自降低交付要求。

- 這是來源版本快照，不能自動連到使用者本機 Git 或追蹤 GitHub 最新版。
  每輪重讀本包與案件進度；更新規則需由維護者重新打包、由使用者重新上傳。
  不執行快照中的本機安裝器、Plugin 更新或本機清理；案件 Git 與後台操作另依實際工具及本次授權。
- 只讀對話已提供或工具已授權可存取的檔案。不能直接讀使用者的 /Users 路徑、
  Google Drive 同步資料夾、公司內網或 localhost。需要來源時請使用者提供相關
  HTML／CSS／JS、文字或重點截圖；連結能否存取以本次工具結果為準。
- 本包只內附 workflow 流程參考，不內附 Lin-EVO、GSAP、Eagle 或系統搜尋 CSS。
  工程規範使用另外啟用的 Lin-EVO，動畫技術使用獨立 GSAP Skills。
  沒有本案後台、evomni-page-composer 或客戶素材，不能編造平台 API／資料綁定。
- 案件全程使用 Claude App；素材由 Claude 提供 prompt，使用者至 ChatGPT 產圖，
  下載後放入本案 image/，自行處理 WebP 與容量，再由 Lin 更新引用並檢查。
  不自動派工 Codex 或操作 ChatGPT 產圖；Eagle／瀏覽器僅在可用且授權範圍內查看參考。
- 使用者已授權本機缺少本輪相關 Skill 時，從已確認來源直接安裝，
  不逐次請示、不覆蓋同名衝突或本機修改；但沒有本機安裝工具的網頁／App
  不能假裝已安裝，改用已啟用 Skill 或提供明確上傳方式。
  此授權不涵蓋應用程式、JS 套件、工程工具庫與系統權限變更。
- 有程式執行能力才處理已提供的工程；有瀏覽器才實看、實測。
  缺能力時提供可下載成果與驗收步驟，明列未驗證，不宣稱已測通過。
  預設第一階段 2560×1280 桌機；已依操作手冊指定桌機後做 RWD 時，確認後直接接續。
- 尚未轉 EVO 的 Git 切版案件，換電腦前先確認範圍與是否需帶操，完成 commit 並 push；
  另一台取得同一版本後先讀交接。已轉 EVO 的案件改至後台，原靜態 Git 不再修改或 push。
- 單一 PDF 超過 10 MB 一律不讀，請提供重點截圖或 .md；未超過上限先問
  現在讀或用到再讀。圖片容量與格式要檢查，轉檔／壓縮由使用者自行處理。
- 工程、SEO、系統公版功能、雙模式動態與工程師交接細則由獨立 Lin-EVO 維護；
  本包不複製另一份。不因缺工具就宣稱已套用或驗證；保留 workflow 的確認關卡。

## 獨立依賴的使用方式

- [Lin-EVO 接入說明](resources/workflow/references/frontend-standards.md)
- [GSAP 按需索引](resources/workflow/references/gsap-skills.md)

來源 commit 與內容雜湊見 SOURCE.json。上傳後仍需在 Claude 啟用並測試。
