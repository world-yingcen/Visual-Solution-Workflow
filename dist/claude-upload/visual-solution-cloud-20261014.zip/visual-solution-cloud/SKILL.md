---
name: visual-solution-cloud
description: 在 Claude 網頁／App 依品牌資料規劃與製作整體視覺網站，內附 LIN 切版、SEO、系統搜尋／詢問車、GSAP 與工程師交接規範；適用提案、切版、校稿與續作。
---

# 整體視覺網站｜Claude 網頁／App 上傳版

以繁體中文與台灣用語協作。先讀 [整體視覺主流程](resources/workflow/GUIDE.md)，
切版／修改／校稿再讀 [LIN](resources/lin/GUIDE.md)，只載入當前需要的參考。
resources 內的 GUIDE.md 都是本包參考，不是需要另外安裝的 Skill。

## 此上傳環境的優先規則

本節優先於參考中僅適用本機的安裝、更新、工具或派工指令；
品牌、設計、工程與使用者已確認規格仍保留，不擅自降低交付要求。

- 這是來源版本快照，不能自動連到使用者本機 Git 或追蹤 GitHub 最新版。
  每輪重讀本包與案件進度；更新規則需由維護者重新打包、由使用者重新上傳。
  不執行 install.py、Plugin 安裝、本機清理或外部部署。
- 只讀對話已提供或工具已授權可存取的檔案。不能直接讀使用者的 /Users 路徑、
  Google Drive 同步資料夾、公司內網或 localhost。需要來源時請使用者提供相關
  HTML／CSS／JS、文字或重點截圖；連結能否存取以本次工具結果為準。
- 本包內附系統參考已核對的規則與搜尋 CSS，但沒有本案後台、
  evomni-page-composer 工程工具庫或客戶素材；不能編造平台 API／資料綁定。
- Chrome、Eagle、Codex 派工與影像工具只在本次確實可用並已授權時操作。
  不可用時完成不依賴工具的部分並列缺口，不要求先安裝全部工具才開始。
- 有程式執行能力才處理已提供的工程；有瀏覽器才實看、實測。
  缺能力時提供可下載成果與驗收步驟，明列未驗證，不宣稱已測通過。
  預設第一階段 2560×1280 桌機，RWD 待使用者另行要求。
- 單一 PDF 超過 10 MB 一律不讀，請提供重點截圖或 .md；未超過上限先問
  現在讀或用到再讀。圖片容量與格式要檢查，轉檔／壓縮由使用者自行處理。
- 每頁只有一個 h1 是公司內部規定；其餘 SEO 責任依 LIN。
  搜尋結果區沿用完整系統 HTML／CSS；詢問車是不可改的公版功能。
  動態須有一般／減少動態兩模式，GSAP pin／scrub 不可留下隱藏內容或留白。
- 切版完成後建立或更新唯一的「工程師交接說明.md」，
  記錄資源、功能、可編輯需求、待接入與兩模式驗收狀態。
  保留方向／視覺／動態／核心片段／整頁確認關卡。

## 主要工程參考

- [HTML／SCSS](resources/lin/references/html-css-rules.md)
- [JavaScript](resources/lin/references/javascript-rules.md)
- [切版端 SEO](resources/lin/references/frontend-seo.md)
- [系統搜尋頁](resources/lin/references/evo-search-reference.md)
- [公版詢問車](resources/lin/references/evo-inquiry-cart-reference.md)
- [EVO 套件宣告](resources/lin/references/evo-vendor-libraries.md)
- [雙模式動態](resources/lin/references/reduced-motion.md)
- [工程師交接](resources/lin/references/engineer-handoff.md)
- [GSAP 按需索引](resources/workflow/references/gsap-skills.md)

來源 commit 與內容雜湊見 SOURCE.json。上傳後仍需在 Claude 啟用並測試。
