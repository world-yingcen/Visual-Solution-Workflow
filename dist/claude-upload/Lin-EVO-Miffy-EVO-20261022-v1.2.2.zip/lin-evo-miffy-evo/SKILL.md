---
name: lin-evo-miffy-evo
description: 在 Claude 網頁／App 製作與校稿靜態網站，或將已確認網站轉成 EVO 匯入包；依使用者指定的 Lin-EVO／Miffy-EVO 分流，內附工程師整站 HTML 套件。
---

# Lin-EVO＋Miffy-EVO

此包提供兩個接續工作的入口：使用者說「使用 Lin-EVO」時完整讀取
[Lin-EVO 規範](resources/Lin-EVO/GUIDE.md)；說「使用 Miffy-EVO」時完整讀取
[Miffy-EVO 規範](resources/Miffy-EVO/GUIDE.md)，再讀該流程要求的參考。
這些是本包的工作指南，不需另外安裝。保留已確認的設計、內容與 RWD 範圍。

## 上傳環境的優先規則

- 本包是來源快照，不執行指南中僅適用本機的 install.py、安裝清單查找或 Skill 來源 Git 更新。
  更新本包需由維護者重新打包並由使用者重新上傳；停用舊版 Lin／Miffy，避免重複規範。
- 案件 Git 另行處理：有實際工具時每輪依指南 fetch 並核對版本，缺工具時提供步驟，
  不假稱已同步。尚未轉 EVO 的 Git 切版案件換電腦前，確認範圍後須 commit 並 push 成功，
  另一台取得同一版本並先讀交接。已成功轉 EVO 的案件改至後台，原靜態 Git 不再修改或 push。
- 只讀使用者提供或工具實際可存取的案件檔案；不能假設可讀本機路徑、localhost、
  公司內網或使用者登入的後台。需要完整 HTML、CSS、JS、素材與案件交接紀錄。
- 整站 HTML 工程師套件位於 resources/Miffy-EVO/evomni-html/；Lin 與 Miffy
  都使用同一份。每輪讀 VERSION 與 SKILL.md，依要求讀 spec.md；套件由人工更新，
  不宣稱已自動確認工程師最新版。原始工程師檔案未改寫。
- 新整站先核對目標支援整站 HTML 匯入；既有 JSON 案件沿用 Miffy 的 legacy-workflow.md，
  本包不包含舊 JSON 工具庫，缺工具時列出缺口，不混用兩種包。
- 有程式執行能力才編譯、執行檢查器與打包；有瀏覽器才實看。Node 不可用時，依工程師
  checklist 檢核後交後台預檢，請使用者回傳報告；不手造 evomni-check.json。
- 實際上傳、匯入與發布依使用者指定的站台及授權；缺操作工具時提供可下載成果和手動步驟。
  本機檢查、後台匯入、編輯儲存及發布後前台分開記錄，未執行標待驗。
- 圖片處理沿用本案分工；不因打包而擅自降低畫質。工程師套件、示範網站與本包來源紀錄
  不混進客戶網站交付 ZIP。

兩個 Skill 各自的來源路徑、可用的 Git commit、工程師套件版本與檔案雜湊見 SOURCE.json。打包驗證不代表已在 Claude
上傳執行，也不代表已在本案 EVO 後台完成驗收。
