# GSAP｜使用者分別上傳的技術 Skills

本包不內附 GSAP。使用者會分別上傳並啟用，依實際可用清單按需使用；不要求安裝本機套件、不猜其他上傳包路徑、不宣稱每輪已載入全部。

| 需求 | 對應 Skill |
|---|---|
| 基本動畫、easing、matchMedia | gsap-core |
| 時間軸與連續轉場 | gsap-timeline |
| 捲動、pin、scrub | gsap-scrolltrigger |
| 效能 | gsap-performance |
| 額外 plugin | gsap-plugins |
| 數值工具 | gsap-utils |
| 已有 React／Next.js | gsap-react |
| 已有 Vue／Nuxt／Svelte | gsap-frameworks |

沿用案件實際 GSAP 版本，技術範例不取代 Lin-EVO 結構與品牌分鏡。缺相關 Skill 時明列尚未取得，先完成可做的規劃或查已授權官方資料；不自行加入框架、效果或套件。