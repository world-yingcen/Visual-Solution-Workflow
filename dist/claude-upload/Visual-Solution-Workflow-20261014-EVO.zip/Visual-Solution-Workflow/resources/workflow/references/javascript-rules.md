# 整體視覺｜javascript-rules 接入

本檔僅為舊連結相容入口，不含共用規範副本。先依 [Lin-EVO 接入](frontend-standards.md) 完成更新與重讀，再完整讀取已安裝 Lin-EVO 的 `references/javascript-rules.md`；不能讀到本檔就當作已讀工程規範。

## 方案差異

本方案維持 2560×1280 桌機優先；RWD 僅另行授權。保留已確認構圖與動態，素材依 [素材製作](asset-production.md)、複雜場景依 [技術架構](technical-architecture.md)，核心內頁依 [內頁設計](inner-pages.md)。不引入高效動態上限或角色流程。

## T10｜JavaScript 結構與初始化

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## T11｜Swiper、AOS 與整體視覺動態

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。
