# 整體視覺｜evo-header-reference 接入

本檔僅為舊連結相容入口，不含共用規範副本。先依 [Lin-EVO 接入](frontend-standards.md) 完成更新與重讀，再完整讀取已安裝 Lin-EVO 的 `references/evo-header-reference.md`；不能讀到本檔就當作已讀工程規範。

## 方案差異

本方案維持 2560×1280 桌機優先；RWD 僅另行授權。保留已確認構圖與動態，素材依 [素材製作](asset-production.md)、複雜場景依 [技術架構](technical-architecture.md)，核心內頁依 [內頁設計](inner-pages.md)。不引入高效動態上限或角色流程。

## 已核對來源

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## 結構與識別

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## root 與樣式

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## 漢堡與導覽行為

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## 按鈕與語系

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。

## 適用邊界

對應條文請讀上述 Lin-EVO 文件的對應主題章節；先遵守本檔方案差異。
