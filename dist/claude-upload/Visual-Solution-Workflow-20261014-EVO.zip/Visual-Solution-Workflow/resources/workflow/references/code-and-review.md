# 整體視覺方案｜切版規範總索引

本方案索引。T04～T08、T10、T13 由獨立 Lin-EVO 提供，連結文件僅保留接入與方案差異；其餘編號對應本方案已有規範，不表示移入高效流程。只讀本輪適用文件，但須完整讀取所選章節；未變且本輪已讀內容不重讀。

| 編號 | 主題 | 本套件規範 |
|---|---|---|
| T01 | 依據、範圍、確認責任 | [主入口](../GUIDE.md)、[模式](mode-routing.md) |
| T02 | 環境、檔案、Git | 下方 T02、[檔案管理](project-files.md) |
| T03 | 設計對照、字型、續作 | [視覺系統](visual-system.md)、[交接](codex-handoff.md) |
| T04～T08 | HTML、版面、Common、SCSS、互動狀態 | [完整 HTML／SCSS 規範](html-css-rules.md) |
| T09 | 圖片、素材與來源 | [素材製作](asset-production.md)；容量與格式檢核依 [Lin-EVO 接入](frontend-standards.md) 讀取獨立 Lin-EVO 的 references/implementation-review.md |
| T10～T11 | JS 初始化、Swiper 輪播、AOS 區塊淡入淡出、marquee、整體視覺動態 | [JS 規範](javascript-rules.md)、[marquee 指定參考](evo-marquee-reference.md) |
| T12 | 內容完整性 | [內容盤點](client-content-audit.md)、[整頁完整度](full-page-completeness.md) |
| T13 | Header、Footer、內頁與平台 | [共用頁面規範](shared-page-rules.md)、[內頁設計](inner-pages.md) |
| T14 | 檢查及通過條件 | [視覺 QA](visual-qa.md) |
| T15 | 共用修改與影響檢查 | 下方 T15 |
| T16 | 交付與未驗證事項 | [交接](codex-handoff.md)、[EVO 頁面對照表](evo-preflight.md#交付頁面對照表)、[修正](refinement-loop.md) |

## T02｜環境、檔案與 Git

- 先盤點實際 HTML、SCSS、JS、匯入、編譯、預覽與 Git 狀態；保留未提交修改。沿用既有基底、套件版本、匯入語法與工程入口，不強制改 @import 為 @use。
- Common 只有一份有效來源，不造第二份 _common.source.scss。空檔不代表缺檔或完成；保留有用途的空資料夾及 .gitkeep。確認實際編譯出非空 CSS 且頁面載入再作視覺確認，不手改編譯產物。
- 首頁與各內頁需有實際可瀏覽入口，草稿不算整案完成。工程位置依本案檔案管理，不強迫移到 06-切版。文件、程式與圖片各用必要格式，不限制可觀看的提案產物只能用 MD。
- 新基底須記來源版本，不覆蓋既有案件、不回推來源庫；不擅自移除巢狀 Git。不把憑證寫入網址或文件，不索取明文 Token。安裝、Git 寫入、發布及部署依本次授權，不因切版規範自動執行；使用者要求推到公司 Git 時依 [Git 流程](git-workflow.md) 執行。
- 正常續作沿用有效環境，不反覆重裝；異常先定位。編譯與預覽由同一任務執行，不依賴外部角色交接。

## T15｜新增共用項目與修改後檢查

依 [Lin-EVO 接入](frontend-standards.md) 讀取獨立 Lin-EVO 的 references/implementation-review.md 與本輪相關工程規範；共用影響、單頁隔離、斷點保真、可編輯性及交付表均以該來源維護。

本方案仍以實際視覺／動態 QA 與使用者確認為準；預設 2560×1280，RWD 另行授權，不能把工程檢查當作設計確認。
